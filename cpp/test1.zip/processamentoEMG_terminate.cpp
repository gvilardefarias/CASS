//
// File: processamentoEMG_terminate.cpp
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//

// Include Files
#include "rt_nonfinite.h"
#include "processamentoEMG.h"
#include "processamentoEMG_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void processamentoEMG_terminate()
{
  // (no terminate code required)
}

//
// File trailer for processamentoEMG_terminate.cpp
//
// [EOF]
//
