//
// File: processamentoEMG_initialize.cpp
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//

// Include Files
#include "rt_nonfinite.h"
#include "processamentoEMG.h"
#include "processamentoEMG_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void processamentoEMG_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for processamentoEMG_initialize.cpp
//
// [EOF]
//
