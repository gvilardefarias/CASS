//
// File: nullAssignment.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//
#ifndef NULLASSIGNMENT_H
#define NULLASSIGNMENT_H

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "processamentoEMG_types.h"

// Function Declarations
extern void nullAssignment(double x_data[], int x_size[1]);

#endif

//
// File trailer for nullAssignment.h
//
// [EOF]
//
