//
// File: median.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//
#ifndef MEDIAN_H
#define MEDIAN_H

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "processamentoEMG_types.h"

// Function Declarations
extern double median(const double x_data[], const int x_size[1]);

#endif

//
// File trailer for median.h
//
// [EOF]
//
