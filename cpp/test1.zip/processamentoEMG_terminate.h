//
// File: processamentoEMG_terminate.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//
#ifndef PROCESSAMENTOEMG_TERMINATE_H
#define PROCESSAMENTOEMG_TERMINATE_H

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "processamentoEMG_types.h"

// Function Declarations
extern void processamentoEMG_terminate();

#endif

//
// File trailer for processamentoEMG_terminate.h
//
// [EOF]
//
