//
// File: std.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//
#ifndef STD_H
#define STD_H

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "processamentoEMG_types.h"

// Function Declarations
extern double b_std(const double varargin_1_data[], const int varargin_1_size[2]);

#endif

//
// File trailer for std.h
//
// [EOF]
//
