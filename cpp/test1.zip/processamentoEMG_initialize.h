//
// File: processamentoEMG_initialize.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//
#ifndef PROCESSAMENTOEMG_INITIALIZE_H
#define PROCESSAMENTOEMG_INITIALIZE_H

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "processamentoEMG_types.h"

// Function Declarations
extern void processamentoEMG_initialize();

#endif

//
// File trailer for processamentoEMG_initialize.h
//
// [EOF]
//
