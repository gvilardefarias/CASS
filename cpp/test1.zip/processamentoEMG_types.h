//
// File: processamentoEMG_types.h
//
// MATLAB Coder version            : 3.1
// C/C++ source code generated on  : 23-Oct-2017 02:09:14
//
#ifndef PROCESSAMENTOEMG_TYPES_H
#define PROCESSAMENTOEMG_TYPES_H

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for processamentoEMG_types.h
//
// [EOF]
//
